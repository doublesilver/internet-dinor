import { Phone, Wifi, Tv, Gift, Check } from 'lucide-react';
import { DinoCharacter, DinoGroup } from '../components/DinoCharacter';
import { PlanCard } from '../components/PlanCard';

export default function HomePage() {
  const providers = [
    { id: 'sk', name: 'SK 브로드밴드', variant: 'sk' as const, benefit: '최대 30만원' },
    { id: 'kt', name: 'KT', variant: 'kt' as const, benefit: '최대 25만원' },
    { id: 'lg', name: 'LG U+', variant: 'lg' as const, benefit: '최대 28만원' },
    { id: 'sky', name: '스카이라이프', variant: 'sky' as const, benefit: '최대 20만원' },
    { id: 'hello', name: '헬로비전', variant: 'hello' as const, benefit: '최대 22만원' },
  ];

  const benefits = [
    '가입 사은품 최대 지급',
    '통신사 공식 파트너',
    '빠른 설치 예약',
    '전문 상담 서비스',
  ];

  const popularPlans = [
    {
      provider: 'KT',
      speed: '기가인터넷 500M',
      price: '27,500원',
      originalPrice: '38,500원',
      benefits: ['설치비 무료', 'WiFi 공유기 무상 제공', '24개월 약정'],
      gift: '삼성 갤럭시 버즈 + 10만원 상품권',
      popular: true,
    },
    {
      provider: 'SK 브로드밴드',
      speed: '기가인터넷 1G',
      price: '35,000원',
      originalPrice: '49,500원',
      benefits: ['설치비 무료', 'WiFi 6 공유기 제공', '넷플릭스 3개월 무료'],
      gift: 'LG 스탠바이미 + 20만원 상품권',
    },
    {
      provider: 'LG U+',
      speed: '인터넷+TV 결합',
      price: '42,900원',
      originalPrice: '62,000원',
      benefits: ['설치비 무료', 'IPTV 셋톱박스 제공', 'U+ 모바일tv 무료'],
      gift: '아이패드 + 15만원 상품권',
    },
  ];

  return (
    <div className="min-h-screen" style={{ fontFamily: 'var(--font-body)' }}>
      {/* 헤더 */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl sm:text-3xl" style={{ fontFamily: 'var(--font-title)', color: '#f15c2d' }}>
              인터넷공룡
            </h1>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#providers" className="hover:opacity-70 transition">통신사 비교</a>
              <a href="#benefits" className="hover:opacity-70 transition">혜택 안내</a>
              <button 
                className="px-6 py-2 rounded-lg text-white transition hover:opacity-90"
                style={{ backgroundColor: '#f15c2d' }}
              >
                <Phone className="inline w-4 h-4 mr-2" />
                상담 신청
              </button>
            </nav>
            <button 
              className="md:hidden px-4 py-2 rounded-lg text-white transition hover:opacity-90"
              style={{ backgroundColor: '#f15c2d' }}
            >
              <Phone className="inline w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* 히어로 섹션 - hero-character.png 사용 */}
      <section className="relative overflow-hidden" style={{ backgroundColor: '#f15c2d' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="text-white text-center md:text-left">
              <h2 
                className="text-3xl sm:text-4xl md:text-5xl mb-4 sm:mb-6 leading-tight" 
                style={{ fontFamily: 'var(--font-title)' }}
              >
                인터넷/TV 가입
                <br />
                비교는 인터넷공룡
              </h2>
              <p className="text-base sm:text-xl mb-6 sm:mb-8 opacity-90">
                최저가 요금제와 최대 혜택을 한눈에 비교하고
                <br className="hidden sm:block" />
                지금 바로 신청하세요!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <button 
                  className="px-6 sm:px-8 py-3 sm:py-4 rounded-lg text-base sm:text-lg transition hover:opacity-90 shadow-lg"
                  style={{ backgroundColor: '#FFEF0A', color: '#333' }}
                >
                  <Gift className="inline w-5 h-5 mr-2" />
                  혜택 확인하기
                </button>
                <button className="px-6 sm:px-8 py-3 sm:py-4 bg-white/20 backdrop-blur-sm rounded-lg text-base sm:text-lg text-white hover:bg-white/30 transition">
                  요금제 비교
                </button>
              </div>
            </div>
            {/* 히어로 캐릭터 - 우측 배치 */}
            <div className="flex justify-center order-first md:order-last">
              <DinoCharacter variant="hero" className="w-full max-w-sm md:max-w-md drop-shadow-2xl" />
            </div>
          </div>
        </div>
        {/* 파도 효과 */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-12 sm:h-16">
            <path 
              d="M0,60 C200,100 400,20 600,60 C800,100 1000,20 1200,60 L1200,120 L0,120 Z" 
              fill="white"
            />
          </svg>
        </div>
      </section>

      {/* 프로모션 배너 - promo-banner-characters.png 사용 */}
      <section className="py-8 sm:py-16 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #f15c2d 0%, #ff7f50 100%)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 sm:p-12 shadow-2xl">
            <div className="grid md:grid-cols-2 gap-6 sm:gap-8 items-center">
              {/* 좌측 - 단체 캐릭터 */}
              <div className="flex justify-center order-last md:order-first">
                <DinoGroup className="drop-shadow-xl scale-75 sm:scale-100" />
              </div>
              {/* 우측 - 텍스트 영역 */}
              <div className="text-white text-center md:text-left">
                <h3 
                  className="text-2xl sm:text-3xl md:text-4xl mb-4 leading-tight" 
                  style={{ fontFamily: 'var(--font-title)' }}
                >
                  너 빼고 다 신청 중..
                  <br />
                  혜택이 이렇게나 많았다고?
                </h3>
                <ul className="space-y-3 mb-8">
                  {benefits.map((benefit, index) => (
                    <li key={index} className="flex items-center justify-center md:justify-start text-base sm:text-lg">
                      <Check className="w-5 sm:w-6 h-5 sm:h-6 mr-2 sm:mr-3 flex-shrink-0" style={{ color: '#FFEF0A' }} />
                      {benefit}
                    </li>
                  ))}
                </ul>
                <button 
                  className="px-6 sm:px-8 py-3 sm:py-4 rounded-lg text-base sm:text-lg transition hover:scale-105 shadow-lg"
                  style={{ backgroundColor: '#FFEF0A', color: '#333' }}
                >
                  지금 바로 혜택 받기 →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 통신사 섹션 - char-*.png 사용 */}
      <section id="providers" className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-4xl mb-4" 
              style={{ fontFamily: 'var(--font-title)', color: '#333' }}
            >
              주요 통신사 비교
            </h2>
            <p className="text-xl" style={{ color: '#666' }}>
              원하는 통신사를 선택하고 최적의 요금제를 찾아보세요
            </p>
          </div>

          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-8">
            {providers.map((provider) => (
              <div 
                key={provider.id}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer"
              >
                <div className="flex flex-col items-center">
                  <DinoCharacter variant={provider.variant} className="w-32 h-32 mb-4" />
                  <h3 className="text-xl mb-2" style={{ color: '#333' }}>
                    {provider.name}
                  </h3>
                  <div 
                    className="text-sm px-4 py-1 rounded-full mb-4"
                    style={{ backgroundColor: '#FFE9E2', color: '#f15c2d' }}
                  >
                    사은품 {provider.benefit}
                  </div>
                  <button 
                    className="w-full py-2 rounded-lg transition hover:opacity-90"
                    style={{ backgroundColor: '#2DC2F1', color: 'white' }}
                  >
                    자세히 보기
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 혜택 안내 */}
      <section id="benefits" className="py-20" style={{ backgroundColor: '#FFE9E2' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-4xl mb-4" 
              style={{ fontFamily: 'var(--font-title)', color: '#333' }}
            >
              왜 인터넷공룡일까요?
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: '#f15c2d' }}>
                <Gift className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl mb-3" style={{ color: '#333' }}>최대 혜택 보장</h3>
              <p style={{ color: '#666' }}>
                가입 사은품과 요금 할인을 모두 챙겨드립니다
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: '#2DC2F1' }}>
                <Wifi className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl mb-3" style={{ color: '#333' }}>빠른 개통</h3>
              <p style={{ color: '#666' }}>
                신청 후 최대 3일 내 설치 완료
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: '#FFEF0A' }}>
                <Tv className="w-8 h-8" style={{ color: '#333' }} />
              </div>
              <h3 className="text-2xl mb-3" style={{ color: '#333' }}>인터넷+TV 결합</h3>
              <p style={{ color: '#666' }}>
                결합 상품으로 더욱 큰 할인 혜택
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 인기 요금제 섹션 */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-4xl mb-4" 
              style={{ fontFamily: 'var(--font-title)', color: '#f15c2d' }}
            >
              🔥 인기 요금제
            </h2>
            <p className="text-xl" style={{ color: '#666' }}>
              많은 고객들이 선택한 베스트 요금제를 확인해보세요
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {popularPlans.map((plan) => (
              <PlanCard key={plan.provider} plan={plan} />
            ))}
          </div>
        </div>
      </section>

      {/* 하단 CTA - cta-character.png 사용 */}
      <section className="py-20" style={{ backgroundColor: '#333' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex items-center gap-6">
              {/* CTA 캐릭터 */}
              <DinoCharacter variant="cta" className="w-48 h-48 flex-shrink-0" />
              <div className="text-white">
                <h3 
                  className="text-3xl mb-3" 
                  style={{ fontFamily: 'var(--font-title)' }}
                >
                  지금 바로 상담받고
                  <br />
                  최대 혜택 받아가세요!
                </h3>
                <p className="text-lg opacity-80">
                  전문 상담사가 최적의 요금제를 안내해드립니다
                </p>
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <button 
                className="px-10 py-5 rounded-lg text-xl transition hover:scale-105 shadow-lg"
                style={{ backgroundColor: '#f15c2d', color: 'white', fontFamily: 'var(--font-title)' }}
              >
                <Phone className="inline w-6 h-6 mr-3" />
                전화 상담 신청
              </button>
              <button 
                className="px-10 py-5 rounded-lg text-xl transition hover:scale-105"
                style={{ backgroundColor: '#2DC2F1', color: 'white' }}
              >
                카카오톡 상담
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 푸터 */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 
                className="text-2xl mb-4" 
                style={{ fontFamily: 'var(--font-title)', color: '#f15c2d' }}
              >
                인터넷공룡
              </h4>
              <p className="text-sm opacity-70">
                인터넷/TV 가입 비교 플랫폼
                <br />
                최대 사은품 지급 보장
              </p>
            </div>
            <div>
              <h5 className="mb-4">고객센터</h5>
              <p className="text-sm opacity-70">
                평일 09:00 - 18:00
                <br />
                주말 및 공휴일 휴무
                <br />
                <a href="tel:1588-0000" className="hover:opacity-100 transition">
                  📞 1588-0000
                </a>
              </p>
            </div>
            <div>
              <h5 className="mb-4">바로가기</h5>
              <ul className="text-sm space-y-2 opacity-70">
                <li><a href="#" className="hover:opacity-100 transition">회사소개</a></li>
                <li><a href="#" className="hover:opacity-100 transition">이용약관</a></li>
                <li><a href="#" className="hover:opacity-100 transition">개인정보처리방침</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm opacity-50">
            © 2026 인터넷공룡. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}