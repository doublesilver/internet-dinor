import { Home, ArrowLeft } from 'lucide-react';
import { DinoCharacter } from '../components/DinoCharacter';
import { Link } from 'react-router';

export default function NotFoundPage() {
  return (
    <div 
      className="min-h-screen flex items-center justify-center px-4"
      style={{ fontFamily: 'var(--font-body)', backgroundColor: '#FFE9E2' }}
    >
      <div className="text-center max-w-2xl">
        {/* 404 캐릭터 */}
        <DinoCharacter variant="404" className="w-96 h-96 mx-auto mb-8" />
        
        <h1 
          className="text-6xl mb-4" 
          style={{ fontFamily: 'var(--font-title)', color: '#f15c2d' }}
        >
          404
        </h1>
        
        <h2 
          className="text-3xl mb-6" 
          style={{ fontFamily: 'var(--font-title)', color: '#333' }}
        >
          페이지를 찾을 수 없어요
        </h2>
        
        <p className="text-lg mb-8" style={{ color: '#666' }}>
          요청하신 페이지가 삭제되었거나 주소가 변경되었을 수 있습니다.
          <br />
          인터넷 연결이 끊긴 공룡처럼 당황스럽네요! 😅
        </p>
        
        <div className="flex gap-4 justify-center">
          <Link to="/">
            <button 
              className="px-8 py-4 rounded-lg text-lg transition hover:opacity-90 shadow-lg flex items-center gap-2"
              style={{ backgroundColor: '#f15c2d', color: 'white' }}
            >
              <Home className="w-5 h-5" />
              홈으로 돌아가기
            </button>
          </Link>
          
          <button 
            onClick={() => window.history.back()}
            className="px-8 py-4 rounded-lg text-lg transition hover:opacity-90 shadow-lg flex items-center gap-2"
            style={{ backgroundColor: '#2DC2F1', color: 'white' }}
          >
            <ArrowLeft className="w-5 h-5" />
            이전 페이지
          </button>
        </div>
        
        <div className="mt-12 p-6 bg-white rounded-2xl shadow-lg">
          <h3 className="mb-4" style={{ color: '#333' }}>
            도움이 필요하신가요?
          </h3>
          <p className="text-sm mb-4" style={{ color: '#666' }}>
            인터넷/TV 가입 상담이 필요하시다면 언제든 문의해주세요
          </p>
          <Link to="/">
            <button 
              className="px-6 py-3 rounded-lg transition hover:opacity-90"
              style={{ backgroundColor: '#FFEF0A', color: '#333' }}
            >
              상담 신청하기
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
