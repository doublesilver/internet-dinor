import { DinoCharacter } from './DinoCharacter';

interface LoadingSpinnerProps {
  message?: string;
}

export function LoadingSpinner({ message = '로딩 중...' }: LoadingSpinnerProps) {
  return (
    <div className="flex flex-col items-center justify-center p-8">
      <div className="animate-bounce">
        <DinoCharacter variant="loading" className="w-32 h-32" />
      </div>
      <p className="mt-4 text-lg" style={{ color: '#666' }}>
        {message}
      </p>
    </div>
  );
}

// 전체 페이지 로딩 스피너
export function FullPageLoading({ message = '페이지를 불러오는 중...' }: LoadingSpinnerProps) {
  return (
    <div 
      className="min-h-screen flex items-center justify-center"
      style={{ backgroundColor: '#FFE9E2' }}
    >
      <LoadingSpinner message={message} />
    </div>
  );
}
