import { Check, Zap } from 'lucide-react';

interface Plan {
  provider: string;
  speed: string;
  price: string;
  originalPrice?: string;
  benefits: string[];
  gift: string;
  popular?: boolean;
}

interface PlanCardProps {
  plan: Plan;
}

export function PlanCard({ plan }: PlanCardProps) {
  const { provider, speed, price, originalPrice, benefits, gift, popular = false } = plan;
  return (
    <div 
      className={`relative bg-white rounded-2xl p-6 shadow-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 ${
        popular ? 'ring-2' : ''
      }`}
      style={popular ? { borderColor: '#f15c2d' } : {}}
    >
      {popular && (
        <div 
          className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-sm text-white flex items-center gap-1"
          style={{ backgroundColor: '#f15c2d' }}
        >
          <Zap className="w-4 h-4" />
          인기 요금제
        </div>
      )}
      
      <div className="mb-4">
        <h4 className="text-sm opacity-60 mb-1">{provider}</h4>
        <h3 className="text-2xl mb-2" style={{ fontFamily: 'var(--font-title)', color: '#333' }}>
          {speed}
        </h3>
        <div className="flex items-baseline gap-2">
          {originalPrice && (
            <span className="text-sm line-through opacity-50">{originalPrice}</span>
          )}
          <span className="text-3xl" style={{ color: '#f15c2d', fontFamily: 'var(--font-title)' }}>
            {price}
          </span>
          <span className="text-sm opacity-60">/월</span>
        </div>
      </div>

      <div 
        className="mb-4 p-3 rounded-lg text-sm"
        style={{ backgroundColor: '#FFE9E2', color: '#f15c2d' }}
      >
        🎁 {gift}
      </div>

      <ul className="space-y-2 mb-6">
        {benefits.map((benefit, index) => (
          <li key={index} className="flex items-start text-sm">
            <Check className="w-4 h-4 mr-2 flex-shrink-0 mt-0.5" style={{ color: '#2DC2F1' }} />
            <span style={{ color: '#666' }}>{benefit}</span>
          </li>
        ))}
      </ul>

      <button 
        className="w-full py-3 rounded-lg transition hover:opacity-90"
        style={{ backgroundColor: '#2DC2F1', color: 'white' }}
      >
        자세히 보기
      </button>
    </div>
  );
}