# 인터넷공룡 웹사이트 프로젝트

## 프로젝트 개요

인터넷/TV 가입 비교 서비스 "인터넷공룡"의 랜딩 페이지입니다.

### 주요 특징
- ✅ 브랜드 아이덴티티를 반영한 디자인 시스템
- ✅ 귀여운 공룡 캐릭터를 활용한 친근한 UI
- ✅ 주요 통신사 (SK, KT, LG, 스카이라이프, 헬로비전) 비교
- ✅ 요금제 및 혜택 정보 제공
- ✅ 반응형 디자인
- ✅ 404 에러 페이지

---

## 기술 스택

- **프레임워크**: React 18.3.1
- **라우팅**: React Router 7
- **스타일링**: Tailwind CSS v4
- **빌드 도구**: Vite
- **아이콘**: Lucide React
- **타입스크립트**: TypeScript
- **폰트**: Pretendard (본문), Cafe24Ssurround (제목)

---

## 브랜드 컬러

### 메인 컬러
- **주황-레드**: `#f15c2d` - 브랜드 메인 컬러, CTA 버튼, 강조
- **스카이블루**: `#2DC2F1` - 보조 컬러, 버튼, WiFi 아이콘
- **다크그레이**: `#333` - 텍스트, 푸터 배경

### 서브 컬러
- **피치**: `#FFE9E2` - 배경, 강조 영역
- **옐로우**: `#FFEF0A` - 액션 버튼, 강조 포인트

---

## 프로젝트 구조

```
/src/
  /app/
    /components/
      DinoCharacter.tsx       # 공룡 캐릭터 SVG 컴포넌트
      LoadingSpinner.tsx      # 로딩 상태 컴포넌트
      PlanCard.tsx            # 요금제 카드 컴포넌트
      /figma/
        ImageWithFallback.tsx # 이미지 폴백 컴포넌트 (시스템 파일)
      /ui/
        (다양한 UI 컴포넌트들)
    /pages/
      HomePage.tsx            # 메인 홈페이지
      NotFoundPage.tsx        # 404 에러 페이지
    App.tsx                   # 앱 엔트리포인트
    routes.tsx                # 라우터 설정
  /styles/
    fonts.css                 # 폰트 임포트
    index.css                 # 스타일 통합
    tailwind.css              # Tailwind 설정
    theme.css                 # 테마 및 브랜드 컬러 정의
```

---

## 주요 섹션

### 1. 헤더
- 로고 (인터넷공룡)
- 네비게이션 (통신사 비교, 혜택 안내)
- 상담 신청 CTA 버튼
- Sticky 헤더

### 2. 히어로 섹션
- 메인 캐치프레이즈
- 대표 캐릭터 (손 흔드는 공룡)
- CTA 버튼 (혜택 확인하기, 요금제 비교)
- 파도 효과 SVG

### 3. 프로모션 배너
- 5마리 공룡 단체 캐릭터
- 주요 혜택 리스트
- 강조 문구

### 4. 통신사 비교 섹션
- 5개 통신사 카드
  - SK 브로드밴드 (보라 공룡, WiFi)
  - KT (파란 트리케라톱스)
  - LG U+ (흰 양)
  - 스카이라이프 (주황 익룡)
  - 헬로비전 (파란 스테고사우루스, @)
- 사은품 혜택 표시
- 호버 효과

### 5. 혜택 안내 섹션
- 최대 혜택 보장
- 빠른 개통
- 인터넷+TV 결합

### 6. 인기 요금제 섹션
- 3개 요금제 카드
- 원가/할인가 표시
- 사은품 정보
- 인기 뱃지

### 7. 하단 CTA 섹션
- 전화기를 든 공룡 캐릭터
- 전화 상담 신청 버튼
- 카카오톡 상담 버튼

### 8. 푸터
- 회사 정보
- 고객센터 정보
- 바로가기 링크
- 저작권 표시

### 9. 404 페이지
- 어리둥절한 공룡 캐릭터
- WiFi 끊김 표현
- 홈으로 돌아가기 버튼
- 이전 페이지 버튼

---

## 캐릭터 시스템

현재 프로젝트는 **SVG로 구현된 임시 캐릭터**를 사용하고 있습니다.

### 캐릭터 종류
1. **hero** - 히어로 섹션 (손 흔드는 포즈)
2. **promo** - 프로모션용 (기본 포즈)
3. **cta** - 하단 CTA (전화기 들고 있는 포즈)
4. **404** - 404 페이지 (어리둥절한 표정)
5. **loading** - 로딩 상태 (간단한 실루엣)
6. **sk** - SK 브로드밴드 (보라색 + WiFi)
7. **kt** - KT (파란색 + 뿔)
8. **lg** - LG U+ (흰색 + 빨간 원)
9. **sky** - 스카이라이프 (주황색 + 별)
10. **hello** - 헬로비전 (파란색 + @)

### 사용 예시
```tsx
import { DinoCharacter } from './components/DinoCharacter';

<DinoCharacter variant="hero" className="w-full max-w-md" />
```

---

## 라우팅

### 페이지 목록
- `/` - 홈페이지
- `*` - 404 에러 페이지

### 라우터 설정
`/src/app/routes.tsx` 파일에서 React Router의 Data Mode 패턴을 사용하여 라우팅을 구성했습니다.

---

## 스타일링 가이드

### CSS 변수 사용
브랜드 컬러와 폰트는 CSS 변수로 정의되어 있습니다:

```css
/* 브랜드 컬러 */
var(--brand-orange)   /* #f15c2d */
var(--brand-skyblue)  /* #2DC2F1 */
var(--brand-dark)     /* #333 */
var(--brand-peach)    /* #FFE9E2 */
var(--brand-yellow)   /* #FFEF0A */

/* 폰트 */
var(--font-body)      /* Pretendard */
var(--font-title)     /* Cafe24Ssurround */
```

### Tailwind 사용
- 레이아웃: `max-w-7xl mx-auto px-4 sm:px-6 lg:px-8`
- 그리드: `grid md:grid-cols-2 lg:grid-cols-3`
- 간격: `gap-4 gap-8 gap-12`
- 반응형: `sm:`, `md:`, `lg:` 브레이크포인트

---

## 반응형 디자인

### 브레이크포인트
- **모바일**: < 768px
- **태블릿**: 768px ~ 1024px
- **데스크톱**: > 1024px

### 주요 반응형 요소
- 헤더 네비게이션 (모바일에서 단순화 필요)
- 그리드 레이아웃 (모바일 1열, 태블릿 2열, 데스크톱 3-5열)
- 히어로 섹션 (모바일 세로 배치, 데스크톱 가로 배치)

---

## 다음 단계

### 1. 실제 캐릭터 에셋 적용
`ASSET_GUIDE.md` 문서를 참고하여 디자이너가 제작한 PNG 에셋을 적용

### 2. 파비콘 및 메타 태그 설정
- 파비콘 세트 추가
- OG 이미지 설정
- SEO 메타 태그

### 3. 기능 구현
- 상담 신청 폼
- 요금제 상세 페이지
- 통신사별 필터링
- 검색 기능

### 4. 성능 최적화
- 이미지 레이지 로딩
- 코드 스플리팅
- 캐싱 전략

### 5. 접근성 개선
- ARIA 레이블
- 키보드 네비게이션
- 스크린 리더 지원

---

## 개발 가이드

### 로컬 개발
```bash
# 개발 서버 실행 (Figma Make 환경에서 자동 실행)
npm run dev

# 빌드
npm run build
```

### 새 컴포넌트 추가
1. `/src/app/components/` 폴더에 컴포넌트 생성
2. 브랜드 컬러는 인라인 스타일 사용: `style={{ color: '#f15c2d' }}`
3. 폰트는 CSS 변수 사용: `style={{ fontFamily: 'var(--font-title)' }}`

### 새 페이지 추가
1. `/src/app/pages/` 폴더에 페이지 컴포넌트 생성
2. `/src/app/routes.tsx`에 라우트 추가

---

## 라이선스 및 크레딧

- **폰트**: Pretendard (SIL Open Font License), Cafe24Ssurround
- **아이콘**: Lucide React (ISC License)
- **UI 컴포넌트**: shadcn/ui 기반

---

## 문의

프로젝트 관련 문의는 담당자에게 연락 바랍니다.
