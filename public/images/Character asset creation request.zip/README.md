
  # Character asset creation request

  This is a code bundle for Character asset creation request. The original project is available at https://www.figma.com/design/CY7TJHle2FsCMSZqtRXMcm/Character-asset-creation-request.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  